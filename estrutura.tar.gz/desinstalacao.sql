drop table plugins.tipopagamento;
drop sequence plugins.tipopagamento_sequencial_seq; 

drop table plugins.empagemovpagamento;
drop sequence plugins.empagemovpagamento_sequencial_seq; 

drop table plugins.empagemovdetalhetransmissaoautenticacao;
drop sequence plugins.empagemovdetalhetransmissaoautenticacao_sequencial_seq; 

drop table plugins.empagemovpagamentoautenticacao;
drop sequence plugins.empagemovpagamentoautenticacao_sequencial_seq; 
